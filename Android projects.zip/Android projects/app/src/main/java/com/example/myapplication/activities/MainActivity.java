package com.example.myapplication.activities;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.adapter.TodoAdapter;
import com.example.myapplication.database.TodoDatabase;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    TodoAdapter adapter;
    FloatingActionButton fab;
    TodoDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = TodoDatabase.getInstance(this);

        recyclerView = findViewById(R.id.recyclerView);
        fab = findViewById(R.id.fabAddTodo);
        adapter = new TodoAdapter();
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        db.todoDao().getAll().observe(this, todos -> adapter.setTodos(todos));

        fab.setOnClickListener(v -> {
            Intent i = new Intent(this, AddEditTodoActivity.class);
            startActivity(i);
        });
    }
}

