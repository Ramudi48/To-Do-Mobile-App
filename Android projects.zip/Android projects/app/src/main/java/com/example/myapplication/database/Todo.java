package com.example.myapplication.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Todo {
    @PrimaryKey(autoGenerate = true)
    public int id;

    public String title;
    public String description;
    public String dueDate;
    public String tag;
    public boolean isCompleted;

    // Getter for title
    public String getTitle() {
        return title;
    }

    // Setter for title
    public void setTitle(String title) {
        this.title = title;
    }

    // Getter for dueDate
    public String getDueDate() {
        return dueDate;
    }

    // Setter for dueDate
    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    // Getter for description
    public String getDescription() {
        return description;
    }

    // Setter for description
    public void setDescription(String description) {
        this.description = description;
    }

    // Getter for tag
    public String getTag() {
        return tag;
    }

    // Setter for tag
    public void setTag(String tag) {
        this.tag = tag;
    }

    // Getter for isCompleted
    public boolean isCompleted() {
        return isCompleted;
    }

    // Setter for isCompleted
    public void setCompleted(boolean completed) {
        this.isCompleted = completed;
    }
}