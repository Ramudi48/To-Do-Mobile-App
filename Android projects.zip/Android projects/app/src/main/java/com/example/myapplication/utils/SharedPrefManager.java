package com.example.myapplication.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPrefManager {
    private SharedPreferences prefs;
    private SharedPreferences.Editor editor;

    public SharedPrefManager(Context context) {
        prefs = context.getSharedPreferences("user_data", Context.MODE_PRIVATE);
        editor = prefs.edit();
    }

    public void saveUser(String username, String password) {
        editor.putString("username", username);
        editor.putString("password", password); // optionally hash it
        editor.apply();
    }

    public boolean validate(String username, String password) {
        return prefs.getString("username", "").equals(username) &&
                prefs.getString("password", "").equals(password);
    }
}
