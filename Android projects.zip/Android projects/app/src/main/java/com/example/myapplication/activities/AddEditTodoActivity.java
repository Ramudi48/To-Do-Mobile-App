package com.example.myapplication.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;
import com.example.myapplication.database.Todo;
import com.example.myapplication.database.TodoDatabase;

import java.util.concurrent.Executors;

public class AddEditTodoActivity extends AppCompatActivity {
    EditText titleET, descET, dateET, tagET;
    Button saveBtn;
    TodoDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_todo);

        titleET = findViewById(R.id.editTextTitle);
        descET = findViewById(R.id.editTextDescription);
        dateET = findViewById(R.id.editTextDate);
        tagET = findViewById(R.id.editTextTag);
        saveBtn = findViewById(R.id.buttonSave);
        db = TodoDatabase.getInstance(this);

        saveBtn.setOnClickListener(v -> {
            Todo todo = new Todo();
            todo.title = titleET.getText().toString();
            todo.description = descET.getText().toString();
            todo.dueDate = dateET.getText().toString();
            todo.tag = tagET.getText().toString();
            todo.isCompleted = false;

            Executors.newSingleThreadExecutor().execute(() -> db.todoDao().insert(todo));
            finish();
        });
    }
}

